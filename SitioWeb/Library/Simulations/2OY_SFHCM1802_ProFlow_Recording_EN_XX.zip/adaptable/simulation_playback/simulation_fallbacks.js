﻿{
    global: {

    },
    start_unit: {

    },
    tts_options: {

    },
    tts_override: {

    },
    intro_page: {

    },
    intro_page_item: {

    },
    new_page: {

    },
    new_slide: {

    },
    imported_page: {

    },
    new_window: {

    },
    new_window_close: {

    },
    explanation: {

    },
    explanation_long: {

    },
    click: {

    },
    click_SAP: {

    },
    key_press: {

    },
    input_text: {

    },
    select_single: {

    },
    input_radio: {

    },
    scroll_hor: {

    },
    scroll_vert: {

    },
    goto_tourstop: {

    },
    end_unit: {

    },
    kurs: {

    },
    hpqc_header: {

    },
    transaction_info: {

    },
    screenshot_part: {

    },
    hinweis: {

    },
    beschreibung: {

    },
    doc_caption: {

    },
    free_marker: {

    },
    arrow: {

    },
    page_break: {

    },
    doc_properties: {

    },
    doc_revision_entry: {

    },
    doc_input_table: {

    },
    doc_logon_table: {

    },
    swf_page: {

    },
    info_page: {

    },
    form_on: {

    },
    form_off: {

    },
    branch_on: {

    },
    branch_off: {

    },
    mode_change: {

    },
    mode_change_end: {

    },
    free_highlight: {

    },
    mchoice: {

    },
    sqmaquiz: {

    },
    fibquiz: {

    },
    matchquiz: {

    },
    connquiz: {

    },
    mixquiz: {

    },
    scalequiz: {

    },
    gridquiz: {

    },
    puzzlequiz: {

    },
    hotspotquiz: {

    },
    quiz_shuffle_on: {

    },
    quiz_shuffle_off: {

    },
    quiz_eval: {

    },
    slide_arrow: {

    },
    slide_big_arrow: {

    },
    slide_link_textBoxIcon: {

    },
    slide_image: {

    },
    slide_icon_link: {

    },
    slide_hrefarea: {

    },
    guide_init: {

    },
    guide_page: {

    }
}