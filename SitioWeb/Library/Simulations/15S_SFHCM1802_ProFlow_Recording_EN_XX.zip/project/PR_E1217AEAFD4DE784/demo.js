﻿{
"mode":"demo",
"contentlanguage":"en-US",
"macroset":"standard",
"control.mastery_percent":80,
"mediaqualities":".wav",
"ok":"true"}
