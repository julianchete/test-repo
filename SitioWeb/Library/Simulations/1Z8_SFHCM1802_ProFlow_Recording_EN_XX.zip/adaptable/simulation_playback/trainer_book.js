﻿{
'window_cfg_features_fullscreen':true,
'ok':true}
