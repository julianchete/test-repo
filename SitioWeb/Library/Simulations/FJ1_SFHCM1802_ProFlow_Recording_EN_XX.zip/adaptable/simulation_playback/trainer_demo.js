﻿{
'window_cfg_features_fullscreen':true,
'scorm_tracking':'completion',
'aicc_tracking':'completion',
'ok':true}
