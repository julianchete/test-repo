﻿{
"mode":"uebung",
"contentlanguage":"en-GB",
"macroset":"standard",
"control.mastery_percent":80,
"mediaqualities":".wav",
"ok":"true"}
