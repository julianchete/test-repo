Instructions for using the Recording

1. Double Click on Start_Scope_Item_Simulation.htm to start the recording.

2. Browser Requirements

	The preferred Browsers for playback of the Recording are Microsoft Internet Explorer and Mozilla Firefox.

	(a) If you get the 'Java Script is turned off' error, please select 'Allow blocked content'.

	(b) Playback of the recording requires the following settings in your browser:
	- Enabled JavaScript
	- Deactivated Pop-up blocker
	- Activated cookies

	(c) The security model of Google Chrome prevents the playback of content from a file system. Content can only be played back from a Web server.

	(d) Microsoft Edge (Standard Browser for Microsoft Windows 10) is not able to show WPB content.
 
