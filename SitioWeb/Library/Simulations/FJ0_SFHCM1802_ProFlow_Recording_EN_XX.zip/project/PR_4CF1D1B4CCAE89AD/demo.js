﻿{
"mode":"demo",
"contentlanguage":"en-US",
"macroset":"standard",
"control.mastery_percent":80,
"mediaqualities":".wav",
"panel_orientation":"bottom",
"ok":"true"}
